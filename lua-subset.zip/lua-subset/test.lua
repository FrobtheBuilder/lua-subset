function a ()
x = 5
end